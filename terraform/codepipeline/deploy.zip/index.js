const unzip = require('unzip')
const stream = require('stream')
const AWS = require('aws-sdk')
const s3 = new AWS.S3({
  signatureVersion: 'v4'
})
const codepipeline = new AWS.CodePipeline()

exports.handler = (event, context, callback) => {
  const { destinationBucket } = process.env
  const { id, data } = event['CodePipeline.job']
  const [ inputArtifact ] = data.inputArtifacts
  const { bucketName, objectKey } = inputArtifact.location.s3Location

  s3.getObject({
    Bucket: bucketName,
    Key: objectKey
  }, (err, response) => {
    if (err) callback(err)

    const promises = []
    const readStream = new stream.PassThrough()

    readStream.end(response.Body)
    readStream.pipe(unzip.Parse())
    .on('entry', (entry) => {
      if (entry.type === 'File') {
        const promise = new Promise((resolve, reject) => {
          const chunks = []
          entry.on('data', (chunk) => {
            chunks.push(chunk)
          })
          entry.on('end', () => {
            s3.putObject({
              Bucket: destinationBucket,
              Key: entry.path,
              Body: Buffer.concat(chunks)
            }, (err, response) => {
                if (err) {
                    reject(err)
                }
                resolve(response)
            })
          })
        })
        promises.push(promise)
      } else {
        entry.autodrain()
      }
    })
    .on('close', () => {
      Promise.all(promises).then(responses => {
          codepipeline.putJobSuccessResult({
            jobId: id
          }, callback)
      }).catch(err => {
          callback(err)
      })
    })
  })
}
