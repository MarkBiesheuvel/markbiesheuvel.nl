const AWS = require('aws-sdk')
const s3 = new AWS.S3({
  signatureVersion:"v4"
})

exports.handler = (event, context, callback) => {
    const {
        source_bucket,
        source_path,
        destination_bucket,
        destination_path
    } = process.env

    s3.listObjects({
        Bucket: source_bucket,
        Prefix: source_path
    }, (err, objects) => {
        if (err) {
            callback(err)
        }

        const promises = []

        objects.Contents.forEach((object) => {
            const source_key =  object.Key
            const destination_key = destination_path +
                source_key.replace(source_path, '')

            const promise = new Promise((resolve, reject) => {
                s3.copyObject({
                    ACL: "private",
                    Bucket: destination_bucket,
                    Key: destination_key.replace(/^\//, ''),
                    CopySource: `${source_bucket}/${source_key}`
                }, (err, response) => {
                    if (err) {
                        reject(err)
                    }
                    resolve(response)
                })
            })
            promises.push(promise)
        })

        Promise.all(promises).then(responses => {
            callback(null, responses);
        }).catch(err => {
            callback(err)
        })
    })
}
